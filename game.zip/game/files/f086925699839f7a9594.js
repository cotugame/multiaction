function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      'use strict';

      var Obj = require('../obj');

      var Stage = require('../../stages/sample');

      var Boss00 = /*#__PURE__*/function (_Obj) {
        _inherits(Boss00, _Obj);

        var _super = _createSuper(Boss00);

        function Boss00(scene, x, y) {
          var _this;

          _classCallCheck(this, Boss00);

          var chipSize = Stage.chipSize;
          var width = 64;
          var height = 64;
          _this = _super.call(this, x * chipSize + width / 2, (y + 1) * chipSize, width, height);
          _this.mode = 0;
          _this.count = 0;
          var rect = new g.FilledRect({
            scene: scene,
            x: _this.x - _this.width / 2,
            y: _this.y - _this.height,
            width: _this.width,
            height: _this.height,
            cssColor: '#6000a0'
          });
          _this.rect = rect;
          rect.update.add(function () {
            switch (_this.mode) {
              case 0:
                _this.x++;
                rect.x = _this.x;
                rect.modified();

                if (++_this.count > 0x100) {
                  _this.mode++;
                  _this.count = 0;
                }

                break;

              case 1:
                _this.x--;
                rect.x = _this.x;
                rect.modified();

                if (++_this.count > 0x100) {
                  _this.mode--;
                  _this.count = 0;
                }

                break;

              default:
                break;
            }
          });
          scene.append(rect);
          return _this;
        }

        return Boss00;
      }(Obj);

      module.exports = Boss00;
    }, {
      "../../stages/sample": 9,
      "../obj": 3
    }],
    2: [function (require, module, exports) {
      'use strict';

      var Obj = require('../obj');

      var Stage = require('../../stages/sample');

      var Enemy = /*#__PURE__*/function (_Obj2) {
        _inherits(Enemy, _Obj2);

        var _super2 = _createSuper(Enemy);

        function Enemy(scene, x, y) {
          var _this2;

          _classCallCheck(this, Enemy);

          var chipSize = Stage.chipSize;
          var width = 32,
              height = 32;
          _this2 = _super2.call(this, x * chipSize + width / 2, (y + 1) * chipSize, width, height);
          _this2.mode = 0;
          _this2.count = 0;
          var rect = new g.FilledRect({
            scene: scene,
            x: _this2.x - _this2.width / 2,
            y: _this2.y - _this2.height,
            width: _this2.width,
            height: _this2.height,
            cssColor: '#0000ff'
          });
          _this2.rect = rect;
          rect.update.add(function () {
            switch (_this2.mode) {
              case 0:
                _this2.x++;
                rect.x = _this2.x;
                rect.modified();

                if (++_this2.count > 0x100) {
                  _this2.mode++;
                  _this2.count = 0;
                }

                break;

              case 1:
                _this2.x--;
                rect.x = _this2.x;
                rect.modified();

                if (++_this2.count > 0x100) {
                  _this2.mode--;
                  _this2.count = 0;
                }

                break;

              default:
                break;
            }
          });
          scene.append(rect);
          return _this2;
        }

        return Enemy;
      }(Obj);

      module.exports = Enemy;
    }, {
      "../../stages/sample": 9,
      "../obj": 3
    }],
    3: [function (require, module, exports) {
      'use strict';

      var Obj = /*#__PURE__*/function () {
        function Obj(x, y, width, height) {
          _classCallCheck(this, Obj);

          this.x = x;
          this.y = y;
          this.dir = 1;
          this.width = width;
          this.height = height;
          this.life = 4;
          this.dead = false;
          this.rect = null;
        }

        _createClass(Obj, [{
          key: "destroy",
          value: function destroy() {
            this.rect.destroy();
          }
        }, {
          key: "isDead",
          get: function get() {
            return this.dead;
          }
        }]);

        return Obj;
      }();

      module.exports = Obj;
    }, {}],
    4: [function (require, module, exports) {
      'use strict';

      var Obj = require('../obj');

      var Stage = require('../../stages/sample');

      var Normal = /*#__PURE__*/function (_Obj3) {
        _inherits(Normal, _Obj3);

        var _super3 = _createSuper(Normal);

        function Normal(scene, x, y, dir) {
          var _this3;

          _classCallCheck(this, Normal);

          var chipSize = Stage.chipSize;
          _this3 = _super3.call(this, x, y, 8, 8);
          _this3.mode = 0;
          _this3.count = 0;
          var rect = new g.FilledRect({
            scene: scene,
            x: _this3.x - _this3.width / 2,
            y: _this3.y - _this3.height,
            width: _this3.width,
            height: _this3.height,
            cssColor: '#ffffff'
          });
          _this3.rect = rect;
          rect.update.add(function () {
            switch (_this3.mode) {
              case 0:
                _this3.x += dir * 8;
                rect.x = _this3.x + dir * 16;
                rect.modified();

                if (++_this3.count > 0x40) {
                  _this3.mode++;
                  _this3.count = 0;
                  scene.remove(rect);
                  _this3.dead = true;
                }

                break;

              default:
                break;
            }
          });
          scene.append(rect);
          return _this3;
        }

        return Normal;
      }(Obj);

      module.exports = Normal;
    }, {
      "../../stages/sample": 9,
      "../obj": 3
    }],
    5: [function (require, module, exports) {
      'use strict';

      var Obj = require('../obj');

      var Stage = require('../../stages/sample');

      var Player = /*#__PURE__*/function (_Obj4) {
        _inherits(Player, _Obj4);

        var _super4 = _createSuper(Player);

        function Player(x, y, width, height) {
          var _this4;

          _classCallCheck(this, Player);

          _this4 = _super4.call(this, x, y, width, height);
          _this4.attackTimer = 0;
          _this4.attackInterval = 30;
          return _this4;
        }

        _createClass(Player, [{
          key: "isAttack",
          get: function get() {
            if (this.attackInterval === 0 || this.isDead) return false;

            if (++this.attackTimer >= this.attackInterval) {
              this.attackTimer = 0;
              return true;
            }

            return false;
          }
        }], [{
          key: "playerPos",
          get: function get() {
            var chipSize = Stage.chipSize;
            return {
              x: g.game.width / 2,
              y: g.game.height - chipSize * 2
            };
          }
        }]);

        return Player;
      }(Obj);

      module.exports = Player;
    }, {
      "../../stages/sample": 9,
      "../obj": 3
    }],
    6: [function (require, module, exports) {
      'use strict';

      var Player = require('./player');

      var Stage = require('../../stages/stage');

      var Player00 = /*#__PURE__*/function (_Player) {
        _inherits(Player00, _Player);

        var _super5 = _createSuper(Player00);

        function Player00(scene, x, y, camera, id, stage) {
          var _this5;

          _classCallCheck(this, Player00);

          var chipSize = Stage.chipSize;
          var width = 32,
              height = 32;
          _this5 = _super5.call(this, x, y, width, height);
          _this5.mouseOn = false;
          _this5.mouseX = 0;
          _this5.mouseY = 0;
          _this5.mode = 0;
          _this5.count = 0;
          var color = id === g.game.selfId ? '#00ff00' : "#ff0000";
          var rect = new g.FilledRect({
            scene: scene,
            x: _this5.x - _this5.width / 2,
            y: _this5.y - _this5.height,
            width: _this5.width,
            height: _this5.height,
            cssColor: color
          });
          _this5.rect = rect;
          var vx = 0;
          var vy = 0;
          var jump = false;
          rect.update.add(function () {
            var ax = 1 / 2;
            var ay = 1 / 4;
            var sx = 1;
            var maxVx = 4;
            var maxVy = 8;

            if (_this5.isDead) {
              if (y > chipSize * stage.height + height) {
                y = chipSize * stage.height + height;
                _this5.vy = 0;
              }

              _this5.vy += ay;
              y += _this5.vy;
              rect.x = x - width / 2;
              rect.y = y - height;
              rect.modified();
              return;
            }

            if (_this5.mouseOn) {
              if (_this5.mouseX > g.game.width / 2) {
                vx += ax;
                if (vx > maxVx) vx = maxVx;
                _this5.dir = 1;
              } else {
                vx -= ax;
                if (vx < -maxVx) vx = -maxVx;
                _this5.dir = -1;
              }

              if (jump === false) {
                if (_this5.mouseY < g.game.height / 2) {
                  vy = -8;
                  jump = true;
                }
              }
            } else {
              if (vx > 0) {
                vx -= sx;
                if (vx < 0) vx = 0;
              } else {
                vx += sx;
                if (vx > 0) vx = 0;
              }
            }

            x += vx;

            if (vx < 0) {
              if (stage.getAtr(x - width / 2, y - 1) & 8) {
                x += chipSize - (x - width / 2) % chipSize;
                vx = 0;
              }
            } else {
              if (stage.getAtr(x + width / 2, y - 1) & 8) {
                x -= (x - width / 2) % chipSize;
                vx = 0;
              }
            }

            vy += ay;
            if (vy > maxVy) vy = maxVy;
            y += vy;

            if (y > chipSize * stage.height) {
              y = chipSize * stage.height;
              vy = 0;
              jump = false;
            } else {
              if (vy < 0) {
                if (stage.getAtr(x, y - height) & 8) {
                  y += chipSize - y % chipSize;
                  vy = 0;
                }
              } else {
                if (stage.getAtr(x, y) & 8) {
                  y -= y % chipSize;
                  vy = 0;
                  jump = false;
                }
              }
            }

            rect.x = Math.floor(x - width / 2);
            rect.y = Math.floor(y - height);
            rect.modified();

            if (id === g.game.selfId) {
              var playerPos = Player.playerPos;
              camera.x = Math.floor(x - playerPos.x);
              camera.y = Math.floor(y - playerPos.y);
              camera.modified();
            }
          });
          scene.append(rect);
          return _this5;
        }

        return Player00;
      }(Player);

      module.exports = Player00;
    }, {
      "../../stages/stage": 10,
      "./player": 5
    }],
    7: [function (require, module, exports) {
      'use strict';

      var gameScene = require('./scenes/gamescene');

      function main(param) {
        var lastJoinedPlayerId = null;
        g.game.join.add(function (ev) {
          lastJoinedPlayerId = ev.player.id;
          console.log('join', lastJoinedPlayerId);
        });
        var scene = new g.Scene({
          game: g.game,
          assetIds: ["entry"]
        });
        var camera = new g.Camera2D({
          game: g.game
        });
        g.game.focusingCamera = camera;
        g.game.modified = true;
        scene.loaded.add(function () {
          if (g.game.selfId === lastJoinedPlayerId) {
            console.log('owner');
          }

          scene.append(new g.FilledRect({
            scene: scene,
            x: 0,
            y: 0,
            width: g.game.width,
            height: g.game.height,
            cssColor: "black"
          }));
          var button = new g.Sprite({
            scene: scene,
            src: scene.assets["entry"],
            x: (g.game.width - scene.assets["entry"].width) / 2,
            y: (g.game.height - scene.assets["entry"].height) / 2,
            touchable: true,
            local: true
          });
          button.pointDown.add(function (ev) {
            g.game.raiseEvent(new g.MessageEvent({
              playerId: ev.player.id
            }));
          });
          scene.append(button);
          scene.message.add(function (msg) {
            if (!msg.data || !msg.data.playerId) return;
            g.game.replaceScene(gameScene(0, [msg.data.playerId], camera));
          });
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            size: 16
          });
          var label = new g.Label({
            scene: scene,
            font: font,
            text: "id" + g.game.selfId,
            fontSize: 16,
            textColor: "blue",
            x: (g.game.width - scene.assets["entry"].width) / 2,
            y: (g.game.height - scene.assets["entry"].height) / 2
          });
          scene.append(label);
        });
        g.game.pushScene(scene);
      }

      module.exports = main;
    }, {
      "./scenes/gamescene": 8
    }],
    8: [function (require, module, exports) {
      'use strict';

      var Stage = require('../stages/stage');

      var Player = require('../entities/player/player00');

      var Normal = require('../entities/player/normal');

      var Enemy = require('../entities/enemy/enemy');

      var Boss00 = require('../entities/enemy/boss00');

      function gameScene(stageNo, playerIds, camera) {
        var scene = new g.Scene({
          game: g.game,
          assetIds: ["entry"]
        });
        var players = {};
        var enemies = [];
        var pattacks = [];
        console.log('stage', stageNo);
        console.log(playerIds);
        console.log('camera', camera.x, camera.y);
        camera.x = 0;
        camera.y = 0;
        camera.modified();
        scene.loaded.add(function () {
          var stage = new Stage(scene, stageNo);
          var chipSize = Stage.chipSize;
          var width = 32;
          var height = 32;
          var x = 1 * chipSize + width / 2;
          var y = (29 + 1) * chipSize;
          scene.message.add(function (msg) {
            if (!msg.data || !msg.data.playerId) return;
            console.log('msg', msg.data.playerId);
            var id = msg.data.playerId;
            players[id] = new Player(scene, x, y, camera, id, stage);
          });
          playerIds.forEach(function (id) {
            console.log('##', id);
            players[id] = new Player(scene, x, y, camera, id, stage);
          });

          if (players[g.game.selfId] == null) {
            var id = g.game.selfId;
            var button = new g.Sprite({
              scene: scene,
              src: scene.assets["entry"],
              x: (g.game.width - scene.assets["entry"].width) / 2,
              y: (g.game.height - scene.assets["entry"].height) / 2,
              touchable: true,
              local: true
            });
            button.pointDown.add(function (ev) {
              var id = ev.player.id;
              g.game.raiseEvent(new g.MessageEvent({
                playerId: ev.player.id
              }));
            });
            scene.append(button);
          }

          enemies.push(new Enemy(scene, 16, 29));
          enemies.push(new Boss00(scene, 48, 29));
        });
        scene.update.add(function () {
          Object.keys(players).forEach(function (id) {
            var player = players[id];

            if (player.isDead === false) {
              enemies.forEach(function (enemy) {
                var dx = player.rect.x - enemy.x;
                var dy = player.rect.y - enemy.y;
                var dis = Math.pow(dx, 2) + Math.pow(dy, 2);

                if (dis < Math.pow(32, 2)) {
                  player.vy = -4;
                  player.jump = true;
                  player.dead = true;
                }
              });

              if (player.isAttack) {
                pattacks.push(new Normal(scene, player.rect.x + player.width / 2, player.rect.y + player.height / 2, player.dir));
              }
            }
          });

          for (var i = pattacks.length - 1; i >= 0; i--) {
            var atk = pattacks[i];

            if (atk.isDead) {
              atk.destroy();
              pattacks.splice(i, 1);
            } else {
              for (var j = enemies.length - 1; j >= 0; j--) {
                var enemy = enemies[j];
                var dx = atk.x - enemy.x;
                var dy = atk.y - enemy.y;
                var dis = Math.pow(dx, 2) + Math.pow(dy, 2);

                if (dis < Math.pow(32, 2)) {
                  atk.destroy();
                  pattacks.splice(i, 1);

                  if (--enemy.life <= 0) {
                    enemy.destroy();
                    enemies.splice(j, 1);

                    if (enemies.length === 0) {
                      g.game.replaceScene(gameScene(stageNo + 1, Object.keys(players), camera));
                    }
                  }
                }
              }
            }
          }
        });
        scene.pointDownCapture.add(function (ev) {
          var id = ev.player.id;

          if (players[id]) {
            var player = players[id];
            player.mouseOn = true;
            player.mouseX = ev.point.x;
            player.mouseY = ev.point.y;
          }
        });
        scene.pointMoveCapture.add(function (ev) {
          var id = ev.player.id;

          if (players[id]) {
            var player = players[id];
            player.mouseX = ev.point.x + ev.startDelta.x;
            player.mouseY = ev.point.y + ev.startDelta.y;
          }
        });
        scene.pointUpCapture.add(function (ev) {
          var id = ev.player.id;

          if (players[id]) {
            var player = players[id];
            player.mouseOn = false;
          }
        });
        return scene;
      }

      module.exports = gameScene;
    }, {
      "../entities/enemy/boss00": 1,
      "../entities/enemy/enemy": 2,
      "../entities/player/normal": 4,
      "../entities/player/player00": 6,
      "../stages/stage": 10
    }],
    9: [function (require, module, exports) {
      'use strict';

      var Stage = /*#__PURE__*/function () {
        function Stage(scene) {
          _classCallCheck(this, Stage);

          var areaNum = 4;
          this.width = 256;
          this.height = 32;
          this.areas = new Array(areaNum);
          this.areas[0] = new Array(this.height);

          for (var y = 0; y < this.height; y++) {
            this.areas[0][y] = new Array(this.width);

            for (var x = 0; x < this.width; x++) {
              var chr = y < this.height - 2 ? 0 : 8; //	this.areas[0][y][x] = {chr: chr, atr: chr}

              this.areas[0][y][x] = {
                chr: chr,
                atr: chr
              };
            }
          }

          for (var j = 0; j < 64; j++) {
            var length = g.game.random.get(4, 7);

            var _x = g.game.random.get(0, this.width - length - 1);

            var _y = g.game.random.get(0, this.height - 8);

            for (var i = 0; i < length; i++) {
              var _chr = 7;
              this.areas[0][_y][_x + i] = {
                chr: _chr,
                atr: _chr
              };
            }
          }

          for (var _j = 0; _j < 128; _j++) {
            var _length = g.game.random.get(4, 15);

            var _x2 = g.game.random.get(0, this.width - _length - 1);

            var _y2 = g.game.random.get(0, this.height - 4);

            for (var _i = 0; _i < _length; _i++) {
              var _chr2 = 9;
              this.areas[0][_y2][_x2 + _i] = {
                chr: _chr2,
                atr: _chr2
              };
            }
          }
          /*
          		for (let x = 0; x < this.width; x++) {
          			const chr = x%16
          			this.areas[0][0][x] = {chr: chr, atr: chr}
          			this.areas[0][this.height-1][x] = {chr: chr, atr: chr}
          		}
          */


          for (var _y3 = 0; _y3 < this.height; _y3++) {
            var _chr3 = _y3 % 16;

            this.areas[0][_y3][0] = {
              chr: _chr3,
              atr: _chr3
            };
            this.areas[0][_y3][this.width - 1] = {
              chr: _chr3,
              atr: _chr3
            };
          }

          var colors = ['#00c0c0', // 00
          '#0000ff', // 01
          '#ff0000', // 02
          '#ff00ff', // 03
          '#00ff00', // 04
          '#00ffff', // 05
          '#ffff00', // 06
          '#ffffff', // 07
          '#804040', // 08
          '#00a000', // 09
          '#7f0000', // 0a
          '#7f007f', // 0b
          '#007f00', // 0c
          '#007f7f', // 0d
          '#7f7f00', // 0e
          '#7f7f7f' // 0f
          ];
          this.size = 32;
          this.field = new g.E({
            scene: scene
          });

          for (var _y4 = 0; _y4 < this.height; _y4++) {
            for (var _x3 = 0; _x3 < this.width; _x3++) {
              var rect = new g.FilledRect({
                scene: scene,
                x: _x3 * this.size,
                y: _y4 * this.size,
                width: this.size,
                height: this.size,
                //	cssColor: ((x+y)%2 == 0) ? "#000000" : "#6000a0"
                cssColor: colors[this.areas[0][_y4][_x3].chr]
              });
              this.field.append(rect);
            }
          }

          scene.append(this.field);
        }

        _createClass(Stage, [{
          key: "getAtr",
          value: function getAtr(x, y) {
            var chipSize = Stage.chipSize;
            var xx = Math.floor(x / chipSize);
            var yy = Math.floor(y / chipSize);
            if (xx < 0 || xx >= this.width) return 0;
            if (yy < 0 || yy >= this.height) return 0;
            return this.areas[0][yy][xx].atr;
          }
        }, {
          key: "setpos",
          value: function setpos(x, y) {//	this.field.x = (x & -this.size*2)
            //	this.field.y = (y & -this.size*2)
            //	this.field.modified()
          }
        }], [{
          key: "chipSize",
          get: function get() {
            return 32;
          }
        }]);

        return Stage;
      }();

      module.exports = Stage;
    }, {}],
    10: [function (require, module, exports) {
      'use strict';

      var Stage = /*#__PURE__*/function () {
        function Stage(scene, stage) {
          _classCallCheck(this, Stage);

          var areaNum = 1;
          this.width = 256;
          this.height = 32;
          this.areas = new Array(areaNum);
          this.areas[0] = new Array(this.height);

          for (var y = 0; y < this.height; y++) {
            this.areas[0][y] = new Array(this.width);

            for (var x = 0; x < this.width; x++) {
              var chr = y < this.height - 2 ? 0 : 8;
              this.areas[0][y][x] = {
                chr: chr,
                atr: chr
              };
            }
          }

          for (var j = 0; j < 64; j++) {
            var length = Math.floor(g.game.random.generate() * 4) + 4;

            var _x4 = Math.floor(g.game.random.generate() * (this.width - length));

            var _y5 = Math.floor(g.game.random.generate() * (this.height - 8));

            for (var i = 0; i < length; i++) {
              var _chr4 = 7;
              this.areas[0][_y5][_x4 + i] = {
                chr: _chr4,
                atr: _chr4
              };
            }
          }

          for (var _j2 = 0; _j2 < 128; _j2++) {
            var _length2 = Math.floor(g.game.random.generate() * 12) + 4;

            var _x5 = Math.floor(g.game.random.generate() * (this.width - _length2));

            var _y6 = Math.floor(g.game.random.generate() * (this.height - 4));

            for (var _i2 = 0; _i2 < _length2; _i2++) {
              var _chr5 = 9;
              this.areas[0][_y6][_x5 + _i2] = {
                chr: _chr5,
                atr: _chr5
              };
            }
          }

          var colors = ['#000000', // 00
          '#0000ff', // 01
          '#ff0000', // 02
          '#ff00ff', // 03
          '#00ff00', // 04
          '#00ffff', // 05
          '#ffff00', // 06
          '#ffffff', // 07
          '#804040', // 08
          '#00a000', // 09
          '#7f0000', // 0a
          '#7f007f', // 0b
          '#007f00', // 0c
          '#007f7f', // 0d
          '#7f7f00', // 0e
          '#7f7f7f' // 0f
          ];
          this.size = 32;
          this.field = new g.E({
            scene: scene
          });

          for (var _y7 = 0; _y7 < this.height; _y7++) {
            for (var _x6 = 0; _x6 < this.width; _x6++) {
              var rect = new g.FilledRect({
                scene: scene,
                x: _x6 * this.size,
                y: _y7 * this.size,
                width: this.size,
                height: this.size,
                //	cssColor: ((x+y)%2 == 0) ? "#000000" : "#6000a0"
                cssColor: colors[this.areas[0][_y7][_x6].chr]
              });
              this.field.append(rect);
            }
          }

          scene.append(this.field);
        }

        _createClass(Stage, [{
          key: "getAtr",
          value: function getAtr(x, y) {
            var chipSize = Stage.chipSize;
            var xx = Math.floor(x / chipSize);
            var yy = Math.floor(y / chipSize);
            if (xx < 0 || xx >= this.width) return 0;
            if (yy < 0 || yy >= this.height) return 0;
            return this.areas[0][yy][xx].atr;
          }
        }], [{
          key: "chipSize",
          get: function get() {
            return 32;
          }
        }]);

        return Stage;
      }();

      module.exports = Stage;
    }, {}]
  }, {}, [7])(7);
});